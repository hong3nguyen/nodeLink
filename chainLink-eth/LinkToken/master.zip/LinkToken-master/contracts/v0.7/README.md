# LINK Token Contracts v0.7

## Token bridge contracts

LinkToken bridge contracts can be found in the [./bridge](./bridge) directory.
