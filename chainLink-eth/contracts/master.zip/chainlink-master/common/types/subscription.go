package types

// Subscription represents an event subscription where events are
// delivered on a data channel.
// This is a generic interface for Subscription to represent used by clients.

//go:generate mockery --quiet --name Subscription --output ./mocks/ --case=underscore
type Subscription interface {
	// Unsubscribe cancels the sending of events to the data channel
	// and closes the error channel.
	Unsubscribe()
	// Err returns the subscription error channel. The error channel receives
	// a value if there is an issue with the subscription (e.g. the network connection
	// delivering the events has been closed). Only one value will ever be sent.
	// The error channel is closed by Unsubscribe.
	Err() <-chan error
}
