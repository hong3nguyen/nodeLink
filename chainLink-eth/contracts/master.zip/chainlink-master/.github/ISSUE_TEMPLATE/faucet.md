---
name: Faucet Issue
about: Report an issue with a Chainlink LINK Faucet.
title: '[FAUC] <replace with issue title>'
labels: 'Faucet'
assignees: ''
---

**Description**
[replace this line with a clear and concise description of the Chainlink LINK Faucet issue you are experiencing]

**Basic Information**
[replace this line with basic information about the issue you are experiencing, including but not limited to your testnet address, the name and version of your web browser and wallet, and the link to the faucet transaction on Etherscan]

**Steps to Reproduce**
[replace this line with detailed steps to reproduce the issue you are experiencing]

**Additional Information**
[replace this line with any additional information you would like to provide, such as screenshots illustrating the issue]
